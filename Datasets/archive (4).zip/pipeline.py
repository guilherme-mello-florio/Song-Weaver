from mido import MidiFile
import numpy as np
from sys import argv
from os import listdir, mkdir
from os.path import exists

#region FROM mido_utils.py

def parse_events(f):
    midi = MidiFile(f)
    events = []
    for msg in midi:
        if msg.type == 'note_on' or msg.type == 'note_off':
            tp = msg.type
            if msg.velocity == 0:
                tp = 'note_off'
            events.append({
                'type': tp,
                'dt': msg.time,
                'key': msg.note,
                'vel': msg.velocity})
    return events

def translate_file(in_path, out_path):
    '''Read midi file from in_path and create an np array file at out_path'''
    events = parse_events(in_path)
    vecs = np.array([event2vec(e) for e in events])
    np.save(out_path, vecs)

def translate_dir(in_dir, out_dir):
    '''Read all midi files in in_dir and create corrosponding .npy vec files in out_dir'''
    for i, in_path in enumerate(listdir(in_dir)):
        print('Processing file {}: {}'.format(i, in_path), end=' '*50+'\r')
        try:
            translate_file(in_dir+in_path, out_dir+in_path.rstrip('.mid')+'.npy')
        except IOError:
            continue

#endregion

#region FROM mido_utils_v3.py
def event2vec(event):
    '''Transform a single event into a vector of length 4'''
    dt = event['dt']
    on_off = 1 if event['type'] == 'note_on' else 0
    key = int(event['key'])
    vel = int(event['vel'])
    return np.array((dt, on_off, key, vel), dtype=('f4, bool, u1, u1'))
#endregion

if __name__ == '__main__':
    # simple tests
    dirs = []
    out = 'processed/'
    if len(argv) >= 2:
        dirs = [argv[1]]
    if len(argv) == 3:
        out = argv[2]
    elif len(argv) > 3:
        dirs = argv[1:-1]
        out = argv[-1]
    print('Data dirs:\n\t', ', '.join(dirs))
    print('Output dir:\n\t', out)
    if not exists(out):
        mkdir(out)
    for in_dir in dirs:
        print('Translating dir {}'.format(in_dir))
        translate_dir(in_dir, out)
        print()