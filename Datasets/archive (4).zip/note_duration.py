
def events_to_durations(events):
    notes = [(0,0) for _ in range(128)] # make a spot for each note
    durations = [] # empty list which will hold data
    cum_time = 0
    last_start = 0
    for e in events:
        cum_time += e['dt']
        if e['type'] == 'note_on':
            notes[e['key']] = (cum_time, e['vel'])
            last_start = cum_time
        elif e['type'] == 'note_off':
            start, vel = notes[e['key']]
            durations.append({
                'key': e['key'],
                'vel': vel,
                'duration': cum_time - start,
                'dt': start - last_start
            })
            last_start = start
    return durations

def durations_to_events(durations):
    events = [] # empty list which will hold data
    cum_time = 0
    for d in durations:
        cum_time += d['dt']
        events.append({
            'type': 'note_on',
            'cum_time': cum_time,
            'key': d['key'],
            'vel': d['vel']
        })
        events.append({
            'type': 'note_off',
            'cum_time': cum_time+d['duration'],
            'key': d['key'],
            'vel': d['vel']
        })
    events.sort(key='cum_time')
    last_event = 0
    for e in events:
        e['dt'] = last_event - e['cum_time']
        last_event = e['cum_time']
        del e['cum_time']
    return events
