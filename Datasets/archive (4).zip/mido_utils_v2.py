from mido import MidiFile, MidiTrack, Message, merge_tracks, second2tick
import numpy as np
from os import listdir
from os.path import exists
import csv
import sys

def parse_events(f):
    midi = MidiFile(f)
    events = []
    for msg in midi:
        if msg.type == 'note_on' or msg.type == 'note_off':
            tp = msg.type
            if msg.velocity == 0:
                tp = 'note_off'
            events.append({
                'type': tp,
                'dt': msg.time,
                'key': msg.note,
                'vel': msg.velocity})
    return events

def event2vec(event):
    '''Transform a single event into a vector of length 4'''
    dt = event['dt']
    on_off = 1 if event['type'] == 'note_on' else 0
    key = int(event['key'])
    vel = int(event['vel'])
    return np.array((dt, on_off, key, vel), dtype=('f4, bool, u1, u1'))

def translate_file(in_path):
    '''Read midi file from in_path and return a vector representation'''
    events = parse_events(in_path)
    vecs = np.array([event2vec(e) for e in events])
    return vecs

def translate_dir(in_dir, out_file):
    '''Read all midi files in in_dir and create corrosponding a single csv file'''
    if exists(out_file):
        skip_header = True
    else:
        skip_header = False
    f = open(out_file, 'a+')
    w = csv.writer(f, quoting=csv.QUOTE_NONNUMERIC)
    mid_files = listdir(in_dir)
    n = len(mid_files)
    mid_files.sort()
    flush_rate = max((n//20, 15))
    if not skip_header:
        w.writerow(['Delta Time', 'Note on/off', 'Note position', 'Note velocity', 'Filename'])
    for i, in_path in enumerate(mid_files):
        print('Processing file {} of {}: {}'.format(i, n, in_path), end=' '*50+'\r')
        try:
            vecs = translate_file(in_dir+in_path)
        except IOError as e:
            print(e)
            continue
        l = vecs.tolist()
        w.writerow(l[0]+in_path.rstrip('.mid'))
        w.writerows(l[1:])
        if i % flush_rate == 0:
            f.flush()
    f.close()

if __name__ == '__main__':
    # simple tests
    if len(sys.argv) == 2:
        translate_dir(sys.argv[1], 'out.csv')
    elif len(sys.argv) == 3:
        translate_dir(sys.argv[1], sys.argv[2])
    elif len(sys.argv) > 3:
        for d in sys.argv[1:-1]:
            translate_dir(d, sys.argv[-1])

    else:
        print('Usage:\n\tpython mido_utils_v2.py <in_dir_1> ... <in_dir_n> <?out_file="out.csv"?>')